package com.personal.jarvis.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase 1 offline command engine.
 *
 * This is the "deterministic commands" layer required by the project spec:
 * no network calls, no AI model calls, no speech I/O. It recognizes a small
 * fixed set of English and Bangla keywords and returns a plain-text reply.
 *
 * Later phases will route unrecognized input to Gemini (Phase 3) instead of
 * falling through to [UNKNOWN]. Nothing here should be deleted to do that -
 * [CommandEngine.handle] is designed to be called first, with a non-local
 * fallback only triggered on [CommandResult.Unknown].
 */
class CommandEngine(private val appContext: Context) {

    sealed class CommandResult {
        data class Handled(val reply: String) : CommandResult()
        data class Unknown(val originalInput: String) : CommandResult()
    }

    private val timeFormatter = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
    private val dateFormatter = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())

    fun handle(rawInput: String): CommandResult {
        val input = rawInput.trim()
        if (input.isEmpty()) {
            return CommandResult.Handled("...")
        }
        val normalized = input.lowercase(Locale.getDefault())

        return when {
            matchesAny(normalized, "help", "commands", "সাহায্য", "কমান্ড") ->
                CommandResult.Handled(helpText())

            matchesAny(normalized, "time", "সময়", "কয়টা বাজে") ->
                CommandResult.Handled(timeReply())

            matchesAny(normalized, "date", "today", "তারিখ", "আজকে") ->
                CommandResult.Handled(dateReply())

            matchesAny(normalized, "battery", "ব্যাটারি") ->
                CommandResult.Handled(batteryReply())

            matchesAny(normalized, "status", "অবস্থা") ->
                CommandResult.Handled(statusReply())

            matchesAny(normalized, "about", "who are you", "তুমি কে", "পরিচয়") ->
                CommandResult.Handled(aboutReply())

            else -> CommandResult.Unknown(input)
        }
    }

    private fun matchesAny(normalizedInput: String, vararg keywords: String): Boolean {
        return keywords.any { keyword -> normalizedInput.contains(keyword.lowercase(Locale.getDefault())) }
    }

    private fun helpText(): String = """
        Offline commands available right now:
        • time / সময়  — current time
        • date / তারিখ  — today's date
        • battery / ব্যাটারি  — battery level and charging state
        • status / অবস্থা  — quick system status
        • about / পরিচয়  — what JARVIS is, in this phase
        • help / সাহায্য  — this list

        This is Phase 1: everything above runs fully offline, no network
        or AI model calls yet.
    """.trimIndent()

    private fun timeReply(): String {
        val now = timeFormatter.format(Date())
        return "It's $now."
    }

    private fun dateReply(): String {
        val today = dateFormatter.format(Date())
        return "Today is $today."
    }

    private fun batteryReply(): String {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = appContext.registerReceiver(null, filter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

        if (level == -1 || scale <= 0) {
            return "I couldn't read the battery level right now."
        }

        val percent = (level * 100) / scale
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val chargingNote = if (isCharging) "it's charging" else "it's on battery power"

        return "Battery is at $percent%, and $chargingNote."
    }

    private fun statusReply(): String = """
        JARVIS Phase 1 — offline core only.
        • Model: none loaded (Gemini arrives in Phase 3)
        • Voice: not wired up yet (Phase 2)
        • Automation: not wired up yet (Phase 5)
        • Mode: Offline
    """.trimIndent()

    private fun aboutReply(): String =
        "I'm JARVIS, a personal assistant being built in phases. " +
            "Right now I only understand a small set of offline commands - " +
            "say \"help\" to see them."

    companion object {
        const val UNKNOWN_REPLY_PREFIX =
            "I don't have an offline command for that yet. " +
                "Online reasoning isn't connected in this phase."
    }
}
