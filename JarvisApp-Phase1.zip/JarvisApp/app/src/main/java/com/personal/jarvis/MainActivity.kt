package com.personal.jarvis

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.personal.jarvis.engine.CommandEngine
import com.personal.jarvis.model.ChatMessage
import com.personal.jarvis.model.Sender
import com.personal.jarvis.ui.theme.JarvisAccentCyan
import com.personal.jarvis.ui.theme.JarvisAccentViolet
import com.personal.jarvis.ui.theme.JarvisBackground
import com.personal.jarvis.ui.theme.JarvisBubbleAssistant
import com.personal.jarvis.ui.theme.JarvisBubbleUser
import com.personal.jarvis.ui.theme.JarvisSurfaceGlass
import com.personal.jarvis.ui.theme.JarvisTextPrimary
import com.personal.jarvis.ui.theme.JarvisTextSecondary
import com.personal.jarvis.ui.theme.JarvisTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JarvisTheme {
                JarvisApp()
            }
        }
    }
}

@Composable
fun JarvisApp() {
    val context = LocalContext.current
    val commandEngine = remember { CommandEngine(context.applicationContext) }

    var nextId by remember { mutableLongStateOf(0L) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                id = -1L,
                sender = Sender.ASSISTANT,
                text = "JARVIS Phase 1 online — offline commands only. " +
                    "Say \"help\" to see what I can do."
            )
        )
    }
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    fun send() {
        val trimmed = inputText.trim()
        if (trimmed.isEmpty()) return

        nextId += 1
        messages.add(ChatMessage(id = nextId, sender = Sender.USER, text = trimmed))
        inputText = ""

        val result = commandEngine.handle(trimmed)
        val replyText = when (result) {
            is CommandEngine.CommandResult.Handled -> result.reply
            is CommandEngine.CommandResult.Unknown ->
                "${CommandEngine.UNKNOWN_REPLY_PREFIX}\n\nYou said: \"${result.originalInput}\""
        }

        nextId += 1
        messages.add(ChatMessage(id = nextId, sender = Sender.ASSISTANT, text = replyText))
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            coroutineScope.launch {
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    Scaffold(
        containerColor = JarvisBackground,
        topBar = { JarvisTopBar() },
        bottomBar = {
            JarvisInputBar(
                value = inputText,
                onValueChange = { inputText = it },
                onSend = { send() },
                onMicTap = {
                    Toast.makeText(
                        context,
                        "Voice input arrives in Phase 2. Type a command for now.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .background(JarvisBackground)
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items = messages, key = { it.id }) { message ->
                ChatBubble(message)
            }
        }
    }
}

@Composable
private fun JarvisTopBar() {
    Surface(
        color = JarvisBackground,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "JARVIS",
                    color = JarvisTextPrimary,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Phase 1 · Offline core",
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            OnlineOfflineBadge(isOnline = false)
        }
    }
}

@Composable
private fun OnlineOfflineBadge(isOnline: Boolean) {
    val badgeColor = if (isOnline) JarvisAccentCyan else JarvisTextSecondary
    val label = if (isOnline) "Online" else "Offline"

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, badgeColor.copy(alpha = 0.6f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(8.dp)
                .height(8.dp)
                .clip(CircleShape)
                .background(badgeColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = label, color = badgeColor, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == Sender.USER
    val bubbleColor = if (isUser) JarvisBubbleUser else JarvisBubbleAssistant
    val alignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart

    Box(modifier = Modifier.fillMaxWidth()) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier
                .align(alignment)
                .widthIn(max = 280.dp)
                .border(
                    width = 1.dp,
                    color = JarvisAccentCyan.copy(alpha = if (isUser) 0f else 0.25f),
                    shape = RoundedCornerShape(16.dp)
                )
        ) {
            Text(
                text = message.text,
                color = JarvisTextPrimary,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun JarvisInputBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicTap: () -> Unit
) {
    Surface(
        color = JarvisSurfaceGlass,
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMicTap) {
                Icon(
                    imageVector = Icons.Filled.Mic,
                    contentDescription = "Push to talk (Phase 2)",
                    tint = JarvisAccentViolet
                )
            }

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text("Type a command, e.g. \"help\"", color = JarvisTextSecondary)
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = JarvisTextPrimary,
                    unfocusedTextColor = JarvisTextPrimary,
                    cursorColor = JarvisAccentCyan,
                    focusedBorderColor = JarvisAccentCyan,
                    unfocusedBorderColor = JarvisTextSecondary.copy(alpha = 0.4f),
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                )
            )

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(onClick = onSend) {
                Icon(
                    imageVector = Icons.Filled.Send,
                    contentDescription = "Send",
                    tint = JarvisAccentCyan
                )
            }
        }
    }
}
