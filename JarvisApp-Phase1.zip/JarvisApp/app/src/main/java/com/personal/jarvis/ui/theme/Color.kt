package com.personal.jarvis.ui.theme

import androidx.compose.ui.graphics.Color

// "Liquid Glass" inspired palette: deep space background, translucent
// glass panels, and a cyan/violet accent pair.
val JarvisBackground = Color(0xFF0A0E17)
val JarvisSurfaceGlass = Color(0x33232A3D) // translucent glass panel
val JarvisSurfaceGlassStrong = Color(0x55232A3D)
val JarvisAccentCyan = Color(0xFF4FD8EB)
val JarvisAccentViolet = Color(0xFF8A6FFF)
val JarvisTextPrimary = Color(0xFFEAF2FF)
val JarvisTextSecondary = Color(0xFF9AA7C2)
val JarvisBubbleUser = Color(0xFF1E2A4A)
val JarvisBubbleAssistant = Color(0x3D4FD8EB)
val JarvisError = Color(0xFFFF6B6B)
