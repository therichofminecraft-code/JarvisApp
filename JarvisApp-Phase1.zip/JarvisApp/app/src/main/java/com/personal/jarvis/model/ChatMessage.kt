package com.personal.jarvis.model

enum class Sender { USER, ASSISTANT }

data class ChatMessage(
    val id: Long,
    val sender: Sender,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis()
)
