package com.personal.jarvis.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val JarvisDarkScheme = darkColorScheme(
    primary = JarvisAccentCyan,
    secondary = JarvisAccentViolet,
    background = JarvisBackground,
    surface = JarvisSurfaceGlass,
    onPrimary = JarvisBackground,
    onBackground = JarvisTextPrimary,
    onSurface = JarvisTextPrimary,
    error = JarvisError
)

// JARVIS always renders in its dark "liquid glass" theme regardless of
// system setting, since the UI is designed against a dark backdrop.
// isSystemInDarkTheme() is kept here so a light variant can be wired in
// later without touching call sites.
@Composable
fun JarvisTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisDarkScheme,
        typography = JarvisTypography,
        content = content
    )
}
