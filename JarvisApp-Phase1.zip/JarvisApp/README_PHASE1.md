# JARVIS — Phase 1

Minimal, fully compilable Jetpack Compose app. Scope, deliberately:

- Chat UI (message list + input field + send button), dark "liquid glass"
  themed per the spec.
- A push-to-talk mic button that is present and tappable, but only shows a
  toast ("Voice input arrives in Phase 2") — no SpeechRecognizer wiring yet.
- A static Offline badge in the top bar — no network/online mode yet.
- `CommandEngine`: a deterministic, fully offline command router with a
  small set of English + Bangla keyword commands (`help`/`সাহায্য`,
  `time`/`সময়`, `date`/`তারিখ`, `battery`/`ব্যাটারি`, `status`/`অবস্থা`,
  `about`/`পরিচয়`). Anything else returns `CommandResult.Unknown`, which is
  the hook Phase 3 (Gemini) will consume instead of falling through silently.

Not yet included (by design — later phases): SpeechRecognizer, Android
TextToSpeech, Gemini, ElevenLabs, AccessibilityService, Room, WorkManager,
DataStore, wake-word detection. No manifest permissions are declared yet
because nothing in this phase needs any.

## Package layout

```
app/src/main/java/com/personal/jarvis/
  MainActivity.kt              — Compose entry point + full chat UI
  model/ChatMessage.kt         — chat message data class
  engine/CommandEngine.kt      — offline command router
  ui/theme/Color.kt            — "liquid glass" palette
  ui/theme/Type.kt             — typography
  ui/theme/Theme.kt            — MaterialTheme wrapper
```
